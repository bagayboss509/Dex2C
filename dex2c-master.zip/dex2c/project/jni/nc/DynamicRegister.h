#ifndef _DYNAMIC_REGISTER_H_ // !_DYNAMIC_REGISTER_H_
#define _DYNAMIC_REGISTER_H_

#include <jni.h>

const char *dynamic_register_compile_methods(JNIEnv *env);

#endif // !_DYNAMIC_REGISTER_H_